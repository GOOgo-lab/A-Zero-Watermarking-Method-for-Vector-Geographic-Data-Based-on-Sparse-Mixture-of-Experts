#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""V17.12 Sparse MoE ablation re-evaluation with standard paper NC.

This script does not retrain any expert or router.  It reuses existing expert
score tables and RouterNet variant checkpoints, then rebuilds all MoE ablation
statistics with the traditional zero-watermark paper metric:

    NC = 1 - BER = mean(W == W')

It is for the MoE line only:
- descriptor ablation: query-only vs paired descriptor
- fusion ablation: mean / max / confidence
- sparse top-k ablation: top1 / top2 / top3 when variants exist
- protected-role ablation: no protection vs rotate/local protection
- repeated split robustness re-evaluation
- mixed zero-shot and attack-strength sweep re-evaluation when source tables exist
"""
from __future__ import annotations

import argparse
import json
import math
import traceback
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from rb_afl_system.scripts.standard_paper_nc_moe_eval_V17_6 import (
    _attack_summary,
    _copy_watermark_scores_to_primary,
    _load_router_fold_models,
    _router_fuse_scores,
    _safe_float,
)
from rb_afl_system.scripts.sparse_moe_router_V16 import _summary_from_scores
from rb_afl_system.utils import ensure_dir, write_json


def _read_json(path: str | Path) -> Any:
    p = Path(path)
    if not p.is_file():
        return {}
    return json.loads(p.read_text(encoding="utf-8"))


def _safe_name(name: str) -> str:
    bad = ['/', '\\', ':', '*', '?', '"', '<', '>', '|', ' ']
    out = str(name)
    for ch in bad:
        out = out.replace(ch, '_')
    return out


def _finite_float(value: Any, default: float = 0.0) -> float:
    try:
        x = float(value)
    except (TypeError, ValueError):
        return float(default)
    if not math.isfinite(x):
        return float(default)
    return x


def _score_summary(scores: np.ndarray, prefix: str) -> dict[str, Any]:
    scores = np.asarray(scores, dtype=np.float32).reshape(-1)
    if scores.size == 0:
        return {
            f"{prefix}_count": 0,
            f"{prefix}_mean_nc": 0.0,
            f"{prefix}_min_nc": 0.0,
            f"{prefix}_max_nc": 0.0,
            f"{prefix}_std_nc": 0.0,
            f"{prefix}_nc_lt_0_9": 0,
            f"{prefix}_nc_lt_0_8": 0,
        }
    return {
        f"{prefix}_count": int(scores.size),
        f"{prefix}_mean_nc": float(scores.mean()),
        f"{prefix}_min_nc": float(scores.min()),
        f"{prefix}_max_nc": float(scores.max()),
        f"{prefix}_std_nc": float(scores.std()),
        f"{prefix}_nc_lt_0_9": int((scores < 0.9).sum()),
        f"{prefix}_nc_lt_0_8": int((scores < 0.8).sum()),
    }


def _classify_variant(name: str, meta_variant: dict[str, Any] | None = None) -> dict[str, Any]:
    meta = dict(meta_variant or {})
    lower = str(name).lower()
    descriptor = "query_only" if "query" in lower else "paired"
    if "oracle_attack" in lower:
        descriptor = "paired_oracle_attack"

    top_k = meta.get("top_k", None)
    if top_k is None:
        if "top1" in lower:
            top_k = 1
        elif "top2" in lower:
            top_k = 2
        elif "top3" in lower:
            top_k = 3
        else:
            top_k = "unknown"

    fusion = str(meta.get("fusion_mode", ""))
    if not fusion:
        if "confidence" in lower:
            fusion = "confidence"
        elif "mean" in lower:
            fusion = "mean"
        elif "max" in lower:
            fusion = "max"
        else:
            fusion = "unknown"

    protected_roles = list(meta.get("protected_roles", []))
    if not protected_roles:
        if "protect_rotate_local" in lower or "protect" in lower:
            protected_roles = ["rotate", "local_attack"]
    protected_tag = "none" if not protected_roles else "+".join(str(x) for x in protected_roles)

    return {
        "variant_name": name,
        "descriptor_type": descriptor,
        "top_k": top_k,
        "fusion_mode": fusion,
        "protected_roles": protected_tag,
        "is_protected": bool(protected_roles),
        "is_oracle_attack_variant": bool("oracle_attack" in lower),
    }


def _base_standard_rows(expert_table_csv: str | Path, output_dir: Path) -> tuple[pd.DataFrame, list[str], dict[str, Any]]:
    df0 = pd.read_csv(expert_table_csv)
    df, roles = _copy_watermark_scores_to_primary(df0)
    closure_table = output_dir / "expert_table_standard_paper_nc_v17_12.csv"
    df.to_csv(closure_table, index=False, encoding="utf-8-sig")

    nc_cols = [f"nc__{role}" for role in roles if f"nc__{role}" in df.columns]
    if not nc_cols:
        raise RuntimeError(f"No nc__role columns after paper-NC rebuild: {expert_table_csv}")

    nc_mat = df[nc_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0).to_numpy(dtype=np.float32)
    oracle_top1 = nc_mat.max(axis=1)
    dense_mean = nc_mat.mean(axis=1)

    static_scores: list[float] = []
    for _, row in df.iterrows():
        role = str(row.get("static_expert_role", ""))
        static_scores.append(_safe_float(row.get(f"nc__{role}", np.nan), 0.0))
    static = np.asarray(static_scores, dtype=np.float32)

    df["paper_static_gated_nc"] = static
    df["paper_dense_mean_nc"] = dense_mean
    df["paper_oracle_top1_nc"] = oracle_top1

    baseline = {
        "expert_table_csv": str(expert_table_csv),
        "closure_table_csv": str(closure_table),
        "score_mode": "standard_paper_nc_1_minus_ber",
        "roles": roles,
        **_score_summary(static, "static_gated"),
        **_score_summary(dense_mean, "dense_mean"),
        **_score_summary(oracle_top1, "oracle_top1"),
    }
    return df, roles, baseline


def _variant_dirs(variant_root: str | Path) -> list[Path]:
    root = Path(variant_root)
    if not root.is_dir():
        return []
    dirs = [p for p in sorted(root.iterdir()) if p.is_dir() and list(p.glob("fold_*_router_net_v17_1.pt"))]
    return dirs


def _eval_one_variant(df: pd.DataFrame, variant_dir: Path, device: str, output_dir: Path) -> dict[str, Any]:
    name = variant_dir.name
    router_models = _load_router_fold_models(variant_dir, device=str(device))
    scores, roles_str, used_ks, weights, probs, router_roles, router_meta = _router_fuse_scores(
        df.copy(),
        score_prefix="nc__",
        router_models=router_models,
        device=str(device),
    )
    rows = df.copy()
    rows["paper_router_nc"] = scores
    rows["paper_router_roles"] = roles_str
    rows["paper_router_weights"] = weights
    rows["paper_router_used_k"] = used_ks
    rows["paper_router_top1_role"] = [router_roles[int(i)] for i in probs.argmax(axis=1)]
    rows["paper_router_top1_prob"] = probs.max(axis=1)
    for j, role in enumerate(router_roles):
        rows[f"paper_router_prob__{role}"] = probs[:, j]

    safe = _safe_name(name)
    vdir = ensure_dir(output_dir / "variants" / safe)
    rows.to_csv(vdir / f"{safe}_paper_nc_rows_v17_12.csv", index=False, encoding="utf-8-sig")
    _attack_summary(rows, "paper_router_nc").to_csv(
        vdir / f"{safe}_paper_nc_attack_summary_v17_12.csv",
        index=False,
        encoding="utf-8-sig",
    )

    meta_variant = dict(router_meta.get("variant", {}))
    out = {
        **_classify_variant(name, meta_variant),
        "variant_dir": str(variant_dir),
        "num_fold_models": int(router_meta.get("num_fold_models", 0)),
        "router_roles": ",".join(router_roles),
        "rows_csv": str(vdir / f"{safe}_paper_nc_rows_v17_12.csv"),
        "attack_summary_csv": str(vdir / f"{safe}_paper_nc_attack_summary_v17_12.csv"),
        **_score_summary(scores, "router"),
    }
    write_json(vdir / f"{safe}_paper_nc_summary_v17_12.json", out)
    return out


def _eval_context(context_name: str, expert_table_csv: str | Path, variant_root: str | Path, output_dir: str | Path, device: str) -> dict[str, Any]:
    out_dir = ensure_dir(output_dir)
    df, roles, baseline = _base_standard_rows(expert_table_csv, out_dir)
    variant_summaries: list[dict[str, Any]] = []
    for vdir in _variant_dirs(variant_root):
        try:
            print(f"[EVAL-VARIANT] context={context_name} variant={vdir.name}", flush=True)
            variant_summaries.append(_eval_one_variant(df, vdir, device=str(device), output_dir=out_dir))
        except Exception as exc:
            print(f"[WARN] failed variant={vdir}: {exc}", flush=True)
            traceback.print_exc()
            variant_summaries.append({"variant_name": vdir.name, "variant_dir": str(vdir), "error": str(exc)})

    variant_df = pd.DataFrame(variant_summaries)
    if len(variant_df):
        sort_cols = [c for c in ["router_min_nc", "router_mean_nc"] if c in variant_df.columns]
        if sort_cols:
            variant_df = variant_df.sort_values(sort_cols, ascending=[False] * len(sort_cols)).reset_index(drop=True)
    variant_df.to_csv(out_dir / "moe_ablation_variant_summary_paper_nc_v17_12.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame([baseline]).to_csv(out_dir / "moe_ablation_baseline_summary_paper_nc_v17_12.csv", index=False, encoding="utf-8-sig")
    write_json(out_dir / "moe_ablation_baseline_summary_paper_nc_v17_12.json", baseline)

    # Ablation pivot tables.
    if len(variant_df) and "error" not in variant_df.columns:
        pass
    if len(variant_df):
        metric_cols = [c for c in ["router_mean_nc", "router_min_nc", "router_nc_lt_0_9", "router_nc_lt_0_8"] if c in variant_df.columns]
        for group_col in ["descriptor_type", "fusion_mode", "top_k", "protected_roles", "is_protected"]:
            if group_col in variant_df.columns and metric_cols:
                g = variant_df.groupby(group_col, dropna=False)[metric_cols].agg(["mean", "min", "max", "count"])
                g.to_csv(out_dir / f"ablation_by_{group_col}_paper_nc_v17_12.csv", encoding="utf-8-sig")

    context_summary = {
        "context_name": context_name,
        "expert_table_csv": str(expert_table_csv),
        "variant_root": str(variant_root),
        "output_dir": str(out_dir),
        "variant_count": int(len(variant_summaries)),
        **baseline,
    }
    write_json(out_dir / "context_summary_paper_nc_v17_12.json", context_summary)
    return context_summary


def _find_repeat_contexts(repeated_root: str | Path) -> list[dict[str, str]]:
    root = Path(repeated_root)
    if not root.is_dir():
        return []
    contexts: list[dict[str, str]] = []
    for repeat_dir in sorted(root.glob("repeat_*")):
        if not repeat_dir.is_dir():
            continue
        candidates = [
            repeat_dir / "sparse_moe_torch_fusion_v17_1_gated" / "sparse_moe_expert_table_paired_v17_1.csv",
            repeat_dir / "sparse_moe_torch_fusion_v17_1_gated" / "sparse_moe_expert_table_v16.csv",
        ]
        table = next((p for p in candidates if p.is_file()), None)
        variant_root = repeat_dir / "sparse_moe_torch_fusion_v17_1_gated" / "torch_moe_variants"
        if table is not None and variant_root.is_dir():
            contexts.append({"name": repeat_dir.name, "expert_table": str(table), "variant_root": str(variant_root)})
    return contexts


def run_main(args: argparse.Namespace) -> None:
    out_root = ensure_dir(args.output_dir)
    all_context_rows: list[dict[str, Any]] = []

    if args.main_expert_table and args.main_variant_root:
        all_context_rows.append(_eval_context(
            "main_split_moe_ablation",
            args.main_expert_table,
            args.main_variant_root,
            out_root / "main_split_moe_ablation",
            args.device,
        ))

    repeat_contexts = _find_repeat_contexts(args.repeated_root)
    print(f"[REPEATED] found={len(repeat_contexts)}", flush=True)
    repeated_rows: list[dict[str, Any]] = []
    for ctx in repeat_contexts:
        summary = _eval_context(
            f"repeated_{ctx['name']}",
            ctx["expert_table"],
            ctx["variant_root"],
            out_root / "repeated_moe_ablation" / ctx["name"],
            args.device,
        )
        repeated_rows.append(summary)
        all_context_rows.append(summary)

    if repeated_rows:
        rep_df = pd.DataFrame(repeated_rows)
        rep_df.to_csv(out_root / "repeated_context_baseline_summary_paper_nc_v17_12.csv", index=False, encoding="utf-8-sig")

        # Merge all repeat variant summaries into one table.
        merged: list[pd.DataFrame] = []
        for ctx in repeat_contexts:
            p = out_root / "repeated_moe_ablation" / ctx["name"] / "moe_ablation_variant_summary_paper_nc_v17_12.csv"
            if p.is_file():
                d = pd.read_csv(p)
                d.insert(0, "repeat", ctx["name"])
                merged.append(d)
        if merged:
            all_rep = pd.concat(merged, ignore_index=True)
            all_rep.to_csv(out_root / "repeated_all_variant_summary_paper_nc_v17_12.csv", index=False, encoding="utf-8-sig")
            metric_cols = [c for c in ["router_mean_nc", "router_min_nc", "router_nc_lt_0_9", "router_nc_lt_0_8"] if c in all_rep.columns]
            if metric_cols and "variant_name" in all_rep.columns:
                stats = all_rep.groupby("variant_name", dropna=False)[metric_cols].agg(["mean", "std", "min", "max", "count"])
                stats.to_csv(out_root / "repeated_variant_stats_paper_nc_v17_12.csv", encoding="utf-8-sig")

    extra_contexts = []
    if args.mixed_expert_table and Path(args.mixed_expert_table).is_file():
        extra_contexts.append(("mixed_zero_shot_paper_nc", args.mixed_expert_table))
    if args.attack_strength_expert_table and Path(args.attack_strength_expert_table).is_file():
        extra_contexts.append(("attack_strength_sweep_paper_nc", args.attack_strength_expert_table))

    for name, table in extra_contexts:
        all_context_rows.append(_eval_context(
            name,
            table,
            args.main_variant_root,
            out_root / name,
            args.device,
        ))

    pd.DataFrame(all_context_rows).to_csv(out_root / "all_contexts_baseline_summary_paper_nc_v17_12.csv", index=False, encoding="utf-8-sig")
    write_json(out_root / "run_info_v17_12.json", vars(args))


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="V17.12 Sparse MoE ablation re-evaluation with standard paper NC")
    ap.add_argument("--main_expert_table", default="")
    ap.add_argument("--main_variant_root", default="")
    ap.add_argument("--repeated_root", default="")
    ap.add_argument("--mixed_expert_table", default="")
    ap.add_argument("--attack_strength_expert_table", default="")
    ap.add_argument("--output_dir", required=True)
    ap.add_argument("--device", default="cpu")
    return ap


def main() -> None:
    ns = build_parser().parse_args()
    try:
        run_main(ns)
    except Exception as exc:
        print(f"[EXC] moe_ablation_paper_nc_V17_12: {exc}", flush=True)
        traceback.print_exc()
        raise


if __name__ == "__main__":
    main()
