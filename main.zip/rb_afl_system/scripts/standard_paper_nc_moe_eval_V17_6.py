#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""V17.6 standard zero-watermark closure utilities for Sparse MoE.

This script fixes the paper-facing evaluation口径:

1. Robustness / routing scores can be recomputed from recovered watermark
   columns, i.e. wm_nc__role / wm_ber__role, instead of feature_nc columns.
2. Final deployed MoE uniqueness can be pressure-tested on all base identities
   using the same RouterNet + sparse activation + max fusion decision rule.

It does not retrain any expert model.  It only reuses frozen experts and frozen
RouterNet checkpoints.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import traceback
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch

from rb_afl_system.data.dataset.triplet_dataset import _load_sample
from rb_afl_system.engine.checkpoint_io import load_checkpoint
from rb_afl_system.engine.device import resolve_device, resolve_map_location
from rb_afl_system.models.model_registry import build_generator
from rb_afl_system.router.geometry_descriptor import paired_geometry_descriptor
from rb_afl_system.scripts.sparse_moe_fusion_train_V17 import (
    _apply_protected_roles,
    _fuse_scores_for_indices,
    _top_indices,
)
from rb_afl_system.scripts.sparse_moe_router_V16 import (
    BASE_EXPERT_ROLES,
    _attack_summary,
    _bool_arg,
    _load_selected,
    _selected_expert_map,
    _summary_from_scores,
    canonical_attack_role,
    expert_role_for_canonical,
)
from rb_afl_system.scripts.sparse_moe_torch_fusion_train_V17_1 import RouterNet, _predict_torch
from rb_afl_system.watermark.feature_to_bits import feature_to_bits
from rb_afl_system.watermark.metrics import ber_score, nc_score
from rb_afl_system.watermark.zero_watermark import (
    make_random_copyright_bits,
    recover_watermark,
    register_zero_watermark,
)
from rb_afl_system.utils import ensure_dir, write_json


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        out = float(value)
    except (TypeError, ValueError):
        return float(default)
    if not math.isfinite(out):
        return float(default)
    return out


def _load_router_fold_models(variant_dir: str | Path, device: str) -> list[dict[str, Any]]:
    root = Path(variant_dir)
    model_files = sorted(root.glob("fold_*_router_net_v17_1.pt"))
    if not model_files:
        raise FileNotFoundError(f"RouterNet fold checkpoints not found: {root}")
    loaded: list[dict[str, Any]] = []
    for p in model_files:
        ckpt = torch.load(p, map_location="cpu", weights_only=False)
        variant = dict(ckpt["variant"])
        feature_cols = list(ckpt["feature_cols"])
        role_order = list(ckpt["roles"])
        model = RouterNet(
            input_dim=len(feature_cols),
            num_roles=len(role_order),
            hidden_dims=list(variant.get("hidden_dims", [128, 64])),
            dropout=float(variant.get("dropout", 0.10)),
        )
        model.load_state_dict(ckpt["model_state_dict"])
        model.to(torch.device(device))
        model.eval()
        loaded.append(
            {
                "path": str(p),
                "model": model,
                "variant": variant,
                "feature_cols": feature_cols,
                "roles": role_order,
                "scaler": dict(ckpt["scaler"]),
                "alpha": float(ckpt.get("alpha", 8.0)),
                "router_power": float(ckpt.get("router_power", 1.0)),
            }
        )
    return loaded


def _standardize_x(df: pd.DataFrame, feature_cols: list[str], scaler: dict[str, Any]) -> np.ndarray:
    for col in feature_cols:
        if col not in df.columns:
            df[col] = 0.0
    x = df[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0).to_numpy(dtype=np.float32)
    mean = np.asarray(scaler["mean"], dtype=np.float32).reshape(1, -1)
    std = np.asarray(scaler["std"], dtype=np.float32).reshape(1, -1)
    std = np.where(std < 1e-6, 1.0, std)
    if mean.shape[1] != x.shape[1]:
        raise RuntimeError(f"Router scaler dim mismatch: mean={mean.shape}, x={x.shape}")
    return (x - mean) / std


def _predict_router_probabilities(df: pd.DataFrame, router_models: list[dict[str, Any]], device: str) -> tuple[np.ndarray, list[str], dict[str, Any]]:
    probs_acc: np.ndarray | None = None
    role_order: list[str] | None = None
    first_variant: dict[str, Any] | None = None
    alpha_values: list[float] = []
    power_values: list[float] = []

    for item in router_models:
        roles_i = list(item["roles"])
        if role_order is None:
            role_order = roles_i
        elif role_order != roles_i:
            raise RuntimeError(f"Router role order mismatch: {role_order} vs {roles_i}")
        x = _standardize_x(df.copy(), list(item["feature_cols"]), dict(item["scaler"]))
        variant = dict(item["variant"])
        sigmoid_probs, _ = _predict_torch(item["model"], x, device=device, temperature=float(variant.get("temperature", 0.80)))
        probs_acc = sigmoid_probs if probs_acc is None else probs_acc + sigmoid_probs
        first_variant = variant if first_variant is None else first_variant
        alpha_values.append(float(item.get("alpha", 8.0)))
        power_values.append(float(item.get("router_power", 1.0)))

    if probs_acc is None or role_order is None or first_variant is None:
        raise RuntimeError("No RouterNet probabilities produced")
    meta = {
        "variant": first_variant,
        "alpha": float(np.mean(alpha_values)) if alpha_values else 8.0,
        "router_power": float(np.mean(power_values)) if power_values else 1.0,
        "num_fold_models": len(router_models),
    }
    return probs_acc / float(len(router_models)), role_order, meta


def _router_fuse_scores(
    df: pd.DataFrame,
    score_prefix: str,
    router_models: list[dict[str, Any]],
    device: str,
) -> tuple[np.ndarray, list[str], list[int], list[str], np.ndarray, list[str], dict[str, Any]]:
    probs, role_order, meta = _predict_router_probabilities(df, router_models, device)
    missing_cols = [f"{score_prefix}{role}" for role in role_order if f"{score_prefix}{role}" not in df.columns]
    if missing_cols:
        raise RuntimeError(f"Missing score columns for RouterNet roles: {missing_cols}")
    nc = df[[f"{score_prefix}{role}" for role in role_order]].apply(pd.to_numeric, errors="coerce").fillna(0.0).to_numpy(dtype=np.float32)
    variant = dict(meta["variant"])
    selected, used_ks, gap, ent = _top_indices(
        probs,
        top_k=int(variant.get("top_k", 2)),
        adaptive=bool(variant.get("adaptive", False)),
        adaptive_max_k=int(variant.get("adaptive_max_k", 3)),
        confidence_gap=float(variant.get("confidence_gap", 0.16)),
        entropy_threshold=float(variant.get("entropy_threshold", 0.76)),
    )
    selected = _apply_protected_roles(
        selected=selected,
        probs=probs,
        role_order=role_order,
        protected_roles=list(variant.get("protected_roles", [])),
        protect_when_uncertain=bool(variant.get("protect_when_uncertain", True)),
        gap=gap,
        ent=ent,
        confidence_gap=float(variant.get("confidence_gap", 0.16)),
        entropy_threshold=float(variant.get("entropy_threshold", 0.76)),
        max_k=max(
            int(variant.get("top_k", 2)),
            int(variant.get("adaptive_max_k", 3)),
            int(variant.get("top_k", 2)) + len(list(variant.get("protected_roles", []))),
        ),
    )
    scores, roles, used_ks, weight_strings = _fuse_scores_for_indices(
        probs=probs,
        nc=nc,
        selected=selected,
        role_order=role_order,
        fusion_mode=str(variant.get("fusion_mode", "max")),
        alpha=float(meta.get("alpha", 8.0)),
        router_power=float(meta.get("router_power", 1.0)),
    )
    return scores, roles, used_ks, weight_strings, probs, role_order, meta


def _copy_watermark_scores_to_primary(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """Use paper-formula recovered-watermark NC as primary expert score.

    Paper-facing zero-watermark NC is bitwise matching rate:
        NC = 1 - BER = mean(W_i == W'_i)

    Older V17.1 tables may contain wm_nc__role computed by old 0/1-vector
    cosine nc_score.  When wm_ber__role is available, rebuild nc__role as
    1 - wm_ber__role and use it as the only paper NC.
    """
    out = df.copy()
    wm_ber_cols = [c for c in out.columns if c.startswith("wm_ber__")]
    wm_nc_cols = [c for c in out.columns if c.startswith("wm_nc__")]
    if not wm_ber_cols and not wm_nc_cols:
        raise RuntimeError("No wm_ber__ or wm_nc__ columns found in expert table")
    roles = sorted(set([c.replace("wm_ber__", "") for c in wm_ber_cols] + [c.replace("wm_nc__", "") for c in wm_nc_cols]))
    for role in roles:
        out[f"feature_nc_raw__{role}"] = pd.to_numeric(out.get(f"nc__{role}", 0.0), errors="coerce")
        out[f"feature_ber_raw__{role}"] = pd.to_numeric(out.get(f"ber__{role}", 1.0), errors="coerce")
        if f"wm_ber__{role}" in out.columns:
            ber = pd.to_numeric(out[f"wm_ber__{role}"], errors="coerce").fillna(1.0).clip(lower=0.0, upper=1.0)
            out[f"paper_wm_xnor_nc__{role}"] = 1.0 - ber
            out[f"nc__{role}"] = out[f"paper_wm_xnor_nc__{role}"]
            out[f"ber__{role}"] = ber
        elif f"wm_nc__{role}" in out.columns:
            out[f"nc__{role}"] = pd.to_numeric(out[f"wm_nc__{role}"], errors="coerce")
    return out, roles


def eval_table_closure(args: argparse.Namespace) -> dict[str, Any]:
    out_dir = ensure_dir(args.output_dir)
    df0 = pd.read_csv(args.expert_table_csv)
    df, roles = _copy_watermark_scores_to_primary(df0)
    closure_table = out_dir / "sparse_moe_expert_table_standard_zero_watermark_v17_6.csv"
    df.to_csv(closure_table, index=False, encoding="utf-8-sig")

    nc_cols = [f"nc__{role}" for role in roles if f"nc__{role}" in df.columns]
    if not nc_cols:
        raise RuntimeError("No standard zero-watermark nc__ columns generated")
    nc = df[nc_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0).to_numpy(dtype=np.float32)
    role_order = [c.replace("nc__", "") for c in nc_cols]
    oracle_top1 = nc.max(axis=1)
    dense_mean = nc.mean(axis=1)

    static_scores: list[float] = []
    for _, row in df.iterrows():
        role = str(row.get("static_expert_role", ""))
        static_scores.append(_safe_float(row.get(f"nc__{role}", np.nan), 0.0))
    static = np.asarray(static_scores, dtype=np.float32)

    rows_out = df.copy()
    rows_out["standard_static_watermark_nc"] = static
    rows_out["standard_oracle_top1_watermark_nc"] = oracle_top1
    rows_out["standard_dense_mean_watermark_nc"] = dense_mean

    router_summary: dict[str, Any] = {}
    if args.router_variant_dir:
        router_models = _load_router_fold_models(args.router_variant_dir, device=str(args.device))
        scores, roles_str, used_ks, weights, probs, router_roles, router_meta = _router_fuse_scores(
            rows_out,
            score_prefix="nc__",
            router_models=router_models,
            device=str(args.device),
        )
        rows_out["standard_router_watermark_nc"] = scores
        rows_out["standard_router_roles"] = roles_str
        rows_out["standard_router_weights"] = weights
        rows_out["standard_router_used_k"] = used_ks
        rows_out["standard_router_top1_role"] = [router_roles[int(i)] for i in probs.argmax(axis=1)]
        rows_out["standard_router_top1_prob"] = probs.max(axis=1)
        for j, role in enumerate(router_roles):
            rows_out[f"standard_router_prob__{role}"] = probs[:, j]
        router_summary = {
            **_summary_from_scores(scores, "standard_router_watermark"),
            "router_variant": router_meta.get("variant", {}),
            "num_fold_models": int(router_meta.get("num_fold_models", 0)),
        }
        _attack_summary(rows_out, "standard_router_watermark_nc").to_csv(
            out_dir / "attack_summary_standard_router_watermark_v17_6.csv",
            index=False,
            encoding="utf-8-sig",
        )

    rows_csv = out_dir / "standard_zero_watermark_moe_rows_v17_6.csv"
    rows_out.to_csv(rows_csv, index=False, encoding="utf-8-sig")
    summary = {
        "expert_table_csv": str(args.expert_table_csv),
        "closure_table_csv": str(closure_table),
        "rows_csv": str(rows_csv),
        "score_mode": "standard_zero_watermark_recovered_W_vs_W_prime",
        "roles": role_order,
        **_summary_from_scores(static, "standard_static_watermark"),
        **_summary_from_scores(oracle_top1, "standard_oracle_top1_watermark"),
        **_summary_from_scores(dense_mean, "standard_dense_mean_watermark"),
        **router_summary,
    }
    pd.DataFrame([summary]).to_csv(out_dir / "standard_zero_watermark_moe_summary_v17_6.csv", index=False, encoding="utf-8-sig")
    write_json(out_dir / "standard_zero_watermark_moe_summary_v17_6.json", summary)
    return summary


def _ckpt_for_model(search_root: Path, model: str) -> Path:
    candidates = [search_root / "runs" / model / "best.pt"]
    candidates.extend(sorted(search_root.glob(f"**/runs/{model}/best.pt")))
    candidates.extend(sorted(search_root.glob(f"**/{model}/best.pt")))
    seen: set[str] = set()
    unique: list[Path] = []
    for c in candidates:
        s = str(c)
        if s not in seen:
            seen.add(s)
            unique.append(c)
    for c in unique:
        if c.is_file():
            return c
    checked = "\n".join(str(c) for c in unique[:80])
    raise FileNotFoundError(f"best.pt not found for model={model}. Checked:\n{checked}")


def _sample_to_device(sample: dict[str, Any], device: torch.device) -> dict[str, Any]:
    return {k: (v.unsqueeze(0).to(device) if torch.is_tensor(v) else v) for k, v in sample.items()}


def _forward_bits(generator: Any, sample_dir: str, channels: list[str], device: torch.device, bit_length: int, threshold_mode: str) -> np.ndarray:
    sample = _load_sample(sample_dir, channels)
    sample_dev = _sample_to_device(sample, device)
    z = generator(
        grid=sample_dev["grid"],
        tokens=sample_dev["tokens"],
        token_mask=sample_dev["token_mask"],
        graph_nodes=sample_dev["graph_nodes"],
        graph_adj=sample_dev["graph_adj"],
        graph_mask=sample_dev["graph_mask"],
    )
    return feature_to_bits(
        z.detach().cpu().numpy()[0],
        bit_length=int(bit_length),
        threshold_mode=str(threshold_mode),
    )


def _load_generator_for_model(search_root: Path, model: str, device: torch.device, device_arg: str) -> tuple[Any, list[str]]:
    ckpt_path = _ckpt_for_model(search_root, model)
    ckpt = load_checkpoint(str(ckpt_path), map_location=resolve_map_location(device_arg))
    model_cfg = dict(ckpt.get("config", {}))
    channels = list(ckpt.get("channel_names", model_cfg.get("channels", ["occ", "dist", "orient", "density"])))
    model_cfg.update(
        {
            "generator": ckpt.get("generator_name", model_cfg.get("generator", "cnn_baseline")),
            "in_channels": len(channels),
        }
    )
    generator = build_generator(model_cfg).to(device)
    generator.load_state_dict(ckpt["generator"])
    generator.eval()
    print(f"[CKPT] model={model} -> {ckpt_path}", flush=True)
    return generator, channels


def _identity_base_rows(dataset_root: Path) -> list[dict[str, Any]]:
    meta = pd.read_csv(dataset_root / "metadata.csv")
    base = meta[meta["attack_type"].astype(str) == "base"].copy()
    if base.empty:
        raise RuntimeError(f"No base rows found in {dataset_root / 'metadata.csv'}")
    base = base.sort_values("identity").drop_duplicates(subset=["identity"], keep="first")
    return base.to_dict("records")


def _build_pair_descriptor_rows(pair_rows: list[dict[str, Any]]) -> pd.DataFrame:
    desc_rows: list[dict[str, Any]] = []
    for row in pair_rows:
        desc = paired_geometry_descriptor(row["query_sample_dir"], reference_dir=row["registered_sample_dir"])
        desc_rows.append({f"pdesc__{k}": v for k, v in desc.items()})
    return pd.concat([pd.DataFrame(pair_rows).reset_index(drop=True), pd.DataFrame(desc_rows).fillna(0.0).reset_index(drop=True)], axis=1)


def _load_copyright_bits_from_image(
    image_path: str | Path,
    bit_length: int,
    return_shape: bool = False,
) -> np.ndarray | tuple[np.ndarray, tuple[int, int]]:
    from PIL import Image

    p = Path(image_path)
    if not p.is_file():
        raise FileNotFoundError(f"copyright image not found: {p}")

    img0 = Image.open(p).convert("L")
    width, height = img0.size

    if width * height == int(bit_length):
        # The watermark image is already a bit canvas, for example 8 x 32 = 256.
        # Keep its native layout and do not resize, compress, or deform it.
        img = img0
        render_shape = (int(height), int(width))
    else:
        # Backward-compatible path for old copyright images such as logo PNGs.
        # These are converted to a square bit canvas only when they are not already
        # exactly bit_length pixels.
        side = int(round(float(bit_length) ** 0.5))
        if side * side != int(bit_length):
            raise ValueError(
                "copyright image must either have width*height == bit_length "
                f"or bit_length must be square, got image={width}x{height}, bit_length={bit_length}"
            )
        img = img0.resize((side, side), Image.Resampling.LANCZOS)
        render_shape = (int(side), int(side))

    arr = np.asarray(img, dtype=np.float32)
    bits = (arr >= float(arr.mean())).astype(np.uint8).reshape(-1)
    if bits.size != int(bit_length):
        raise RuntimeError(f"copyright bits length mismatch: {bits.size} vs {bit_length}")
    if return_shape:
        return bits, render_shape
    return bits


def _load_copyright_bits(args: argparse.Namespace, bit_length: int) -> np.ndarray:
    image_path = str(getattr(args, "copyright_image", "") or "").strip()
    npy_path = str(getattr(args, "copyright_bits_npy", "") or "").strip()
    if image_path:
        return _load_copyright_bits_from_image(image_path, bit_length)
    if npy_path:
        bits = np.load(npy_path).astype(np.uint8).reshape(-1)
        if bits.size != int(bit_length):
            raise ValueError(f"copyright bits length mismatch: {bits.size} vs {bit_length}")
        return bits
    return make_random_copyright_bits(bit_length, seed=int(args.copyright_seed))


def _recover_nc_from_bits(copyright_bits: np.ndarray, registered_bits: np.ndarray, query_bits: np.ndarray) -> tuple[float, float]:
    # Standard paper-formula zero-watermark closure:
    # Z = W XOR B; W' = Z XOR B'; NC = mean(W == W') = 1 - BER.
    z = register_zero_watermark(copyright_bits, registered_bits)
    recovered = recover_watermark(z, query_bits)
    ber = float(ber_score(copyright_bits, recovered))
    nc = float(1.0 - ber)
    return nc, ber


def eval_final_moe_uniqueness(args: argparse.Namespace) -> dict[str, Any]:
    out_dir = ensure_dir(args.output_dir)
    device_arg = str(args.device)
    device = resolve_device(device_arg)
    dataset_root = Path(args.dataset_root)
    search_root = Path(args.ckpt_search_root)
    selected = _load_selected(args.selected_json)
    roles = [x.strip() for x in str(args.expert_roles).split(",") if x.strip()]
    model_by_role = _selected_expert_map(selected, roles)
    if not model_by_role:
        raise RuntimeError("No selected expert roles resolved from selected_json")
    unique_models = sorted(set(model_by_role.values()))
    base_rows = _identity_base_rows(dataset_root)
    if len(base_rows) < 2:
        raise RuntimeError("Final MoE uniqueness needs at least two identities")
    bit_length = int(args.bit_length)
    copyright_bits = _load_copyright_bits(args, bit_length)
    np.save(out_dir / "copyright_bits_used_v17_6.npy", copyright_bits.astype(np.uint8))
    write_json(
        out_dir / "copyright_bits_info_v17_6.json",
        {
            "bit_length": int(bit_length),
            "copyright_image": str(getattr(args, "copyright_image", "") or ""),
            "copyright_bits_npy": str(getattr(args, "copyright_bits_npy", "") or ""),
            "copyright_seed": int(args.copyright_seed),
            "ones": int(copyright_bits.sum()),
            "zeros": int(copyright_bits.size - copyright_bits.sum()),
            "nc_formula": "paper_xnor_matching_rate_1_minus_ber",
        },
    )

    bits_by_model_identity: dict[str, dict[str, np.ndarray]] = {}
    with torch.no_grad():
        for model in unique_models:
            generator, channels = _load_generator_for_model(search_root, model, device=device, device_arg=device_arg)
            model_bits: dict[str, np.ndarray] = {}
            for row in base_rows:
                identity = str(row["identity"])
                model_bits[identity] = _forward_bits(
                    generator,
                    str(row["sample_dir"]),
                    channels,
                    device,
                    bit_length=bit_length,
                    threshold_mode=str(args.threshold_mode),
                )
            bits_by_model_identity[model] = model_bits
            del generator
            if device.type == "cuda":
                torch.cuda.empty_cache()

    identity_to_dir = {str(r["identity"]): str(r["sample_dir"]) for r in base_rows}
    identities = [str(r["identity"]) for r in base_rows]
    directional_rows: list[dict[str, Any]] = []
    for i, identity_a in enumerate(identities):
        for j, identity_b in enumerate(identities):
            if i == j:
                continue
            row: dict[str, Any] = {
                "registered_identity": identity_a,
                "query_identity": identity_b,
                "registered_sample_dir": identity_to_dir[identity_a],
                "query_sample_dir": identity_to_dir[identity_b],
                "sample_key": f"{identity_a}__TO__{identity_b}",
                "identity": identity_a,
                "attack_type": "cross_identity_base",
                "static_expert_role": "local_attack" if "local_attack" in model_by_role else list(model_by_role.keys())[0],
            }
            for role, model in model_by_role.items():
                bits_a = bits_by_model_identity[model][identity_a]
                bits_b = bits_by_model_identity[model][identity_b]
                wm_nc, wm_ber = _recover_nc_from_bits(copyright_bits, bits_a, bits_b)
                row[f"wm_nc__{role}"] = wm_nc
                row[f"wm_ber__{role}"] = wm_ber
                row[f"nc__{role}"] = wm_nc
                row[f"ber__{role}"] = wm_ber
            static_role = str(row["static_expert_role"])
            row["standard_static_watermark_nc"] = _safe_float(row.get(f"nc__{static_role}", 0.0), 0.0)
            nc_values = np.asarray([_safe_float(row.get(f"nc__{role}", 0.0), 0.0) for role in model_by_role.keys()], dtype=np.float32)
            role_order_init = list(model_by_role.keys())
            best_idx = int(nc_values.argmax())
            row["standard_oracle_top1_watermark_nc"] = float(nc_values[best_idx])
            row["standard_oracle_top1_role"] = role_order_init[best_idx]
            row["standard_dense_mean_watermark_nc"] = float(nc_values.mean())
            directional_rows.append(row)

    direction_df = _build_pair_descriptor_rows(directional_rows)
    router_models = _load_router_fold_models(args.router_variant_dir, device=device_arg)
    scores, roles_str, used_ks, weights, probs, router_roles, router_meta = _router_fuse_scores(
        direction_df,
        score_prefix="nc__",
        router_models=router_models,
        device=device_arg,
    )
    direction_df["standard_router_watermark_nc"] = scores
    direction_df["standard_router_roles"] = roles_str
    direction_df["standard_router_weights"] = weights
    direction_df["standard_router_used_k"] = used_ks
    direction_df["standard_router_top1_role"] = [router_roles[int(i)] for i in probs.argmax(axis=1)]
    direction_df["standard_router_top1_prob"] = probs.max(axis=1)
    for j, role in enumerate(router_roles):
        direction_df[f"standard_router_prob__{role}"] = probs[:, j]

    directional_csv = out_dir / "final_moe_uniqueness_directional_rows_v17_6.csv"
    direction_df.to_csv(directional_csv, index=False, encoding="utf-8-sig")

    pair_rows: list[dict[str, Any]] = []
    for i in range(len(identities)):
        for j in range(i + 1, len(identities)):
            a = identities[i]
            b = identities[j]
            ab = direction_df[(direction_df["registered_identity"].astype(str) == a) & (direction_df["query_identity"].astype(str) == b)].iloc[0]
            ba = direction_df[(direction_df["registered_identity"].astype(str) == b) & (direction_df["query_identity"].astype(str) == a)].iloc[0]
            score_ab = _safe_float(ab.get("standard_router_watermark_nc", 0.0), 0.0)
            score_ba = _safe_float(ba.get("standard_router_watermark_nc", 0.0), 0.0)
            risky = ab if score_ab >= score_ba else ba
            pair_rows.append(
                {
                    "identity_a": a,
                    "identity_b": b,
                    "pair_moe_unique_nc": max(score_ab, score_ba),
                    "score_a_to_b": score_ab,
                    "score_b_to_a": score_ba,
                    "risk_direction": f"{risky['registered_identity']}-> {risky['query_identity']}",
                    "risk_roles": str(risky.get("standard_router_roles", "")),
                    "risk_top1_role": str(risky.get("standard_router_top1_role", "")),
                    "oracle_pair_nc": max(
                        _safe_float(ab.get("standard_oracle_top1_watermark_nc", 0.0), 0.0),
                        _safe_float(ba.get("standard_oracle_top1_watermark_nc", 0.0), 0.0),
                    ),
                    "static_pair_nc": max(
                        _safe_float(ab.get("standard_static_watermark_nc", 0.0), 0.0),
                        _safe_float(ba.get("standard_static_watermark_nc", 0.0), 0.0),
                    ),
                }
            )

    pair_df = pd.DataFrame(pair_rows).sort_values("pair_moe_unique_nc", ascending=False)
    pair_csv = out_dir / "final_moe_uniqueness_pairs_v17_6.csv"
    pair_df.to_csv(pair_csv, index=False, encoding="utf-8-sig")

    scores_arr = pd.to_numeric(pair_df["pair_moe_unique_nc"], errors="coerce").fillna(0.0).to_numpy(dtype=np.float32)
    thresholds = [float(x) for x in str(args.thresholds).split(",") if str(x).strip()]
    summary: dict[str, Any] = {
        "dataset_root": str(dataset_root),
        "selected_json": str(args.selected_json),
        "router_variant_dir": str(args.router_variant_dir),
        "score_mode": "final_moe_standard_zero_watermark_pairwise_uniqueness",
        "identity_count": int(len(identities)),
        "pair_count": int(len(pair_df)),
        "directional_count": int(len(direction_df)),
        "moe_unique_mean_nc": float(scores_arr.mean()) if scores_arr.size else 0.0,
        "moe_unique_max_nc": float(scores_arr.max()) if scores_arr.size else 0.0,
        "worst_pair_identity_a": str(pair_df.iloc[0]["identity_a"]) if not pair_df.empty else "",
        "worst_pair_identity_b": str(pair_df.iloc[0]["identity_b"]) if not pair_df.empty else "",
        "worst_pair_nc": float(pair_df.iloc[0]["pair_moe_unique_nc"]) if not pair_df.empty else 0.0,
        "directional_rows_csv": str(directional_csv),
        "pair_rows_csv": str(pair_csv),
        "role_to_model": model_by_role,
        "router_meta": router_meta,
    }
    for tau in thresholds:
        count = int((scores_arr >= tau).sum())
        key = str(tau).replace(".", "p")
        summary[f"M_at_{key}"] = count
        summary[f"FMR_at_{key}"] = float(count / max(1, len(scores_arr)))
    pd.DataFrame([summary]).to_csv(out_dir / "final_moe_uniqueness_summary_v17_6.csv", index=False, encoding="utf-8-sig")
    write_json(out_dir / "final_moe_uniqueness_summary_v17_6.json", summary)
    return summary


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="V17.6 standard zero-watermark closure for Sparse MoE")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("eval-table", help="Recompute MoE table/router metrics using recovered-watermark NC columns")
    p1.add_argument("--expert_table_csv", required=True)
    p1.add_argument("--router_variant_dir", default="")
    p1.add_argument("--output_dir", required=True)
    p1.add_argument("--device", default="cpu")
    p1.set_defaults(func=eval_table_closure)

    p2 = sub.add_parser("final-uniqueness", help="Final deployed MoE pairwise uniqueness pressure test on base identities")
    p2.add_argument("--dataset_root", required=True)
    p2.add_argument("--selected_json", required=True)
    p2.add_argument("--ckpt_search_root", required=True)
    p2.add_argument("--router_variant_dir", required=True)
    p2.add_argument("--output_dir", required=True)
    p2.add_argument("--expert_roles", default=",".join(BASE_EXPERT_ROLES))
    p2.add_argument("--device", default="auto")
    p2.add_argument("--bit_length", type=int, default=256)
    p2.add_argument("--threshold_mode", default="mean")
    p2.add_argument("--copyright_seed", type=int, default=20260318)
    p2.add_argument("--copyright_image", default="")
    p2.add_argument("--copyright_bits_npy", default="")
    p2.add_argument("--thresholds", default="0.7,0.8,0.9")
    p2.set_defaults(func=eval_final_moe_uniqueness)
    return ap


def main() -> None:
    ap = build_parser()
    ns = ap.parse_args()
    try:
        summary = ns.func(ns)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    except Exception as exc:
        print(f"[EXC] standard_zero_watermark_moe_eval_V17_6: {exc}", flush=True)
        traceback.print_exc()
        raise


if __name__ == "__main__":
    main()
