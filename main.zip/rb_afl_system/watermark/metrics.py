#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""NC and BER metrics."""
from __future__ import annotations
import numpy as np


def nc_score(a: np.ndarray, b: np.ndarray) -> float:
    x = np.asarray(a, dtype=np.float32).reshape(-1)
    y = np.asarray(b, dtype=np.float32).reshape(-1)
    n = min(x.size, y.size)
    if n == 0:
        return 0.0
    x = x[:n]
    y = y[:n]
    denom = float(np.linalg.norm(x) * np.linalg.norm(y))
    if denom < 1e-12:
        return 0.0
    return float(np.dot(x, y) / denom)


def ber_score(a: np.ndarray, b: np.ndarray) -> float:
    x = np.asarray(a, dtype=np.uint8).reshape(-1)
    y = np.asarray(b, dtype=np.uint8).reshape(-1)
    n = min(x.size, y.size)
    if n == 0:
        return 1.0
    return float(np.mean(x[:n] != y[:n]))
